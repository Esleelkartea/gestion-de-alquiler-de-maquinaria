
-----------------------------------------------------------------------------
-- provincias
-----------------------------------------------------------------------------
DROP TABLE provincias CASCADE;
DROP SEQUENCE provincias_idprovincia_seq;


CREATE SEQUENCE provincias_idprovincia_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE provincias
(
	        
    idprovincia INTEGER DEFAULT nextval('provincias_idprovincia_seq') NOT NULL,
	        
    nombre VARCHAR(50),

    PRIMARY KEY (idprovincia)
);




-----------------------------------------------------------------------------
-- localidades
-----------------------------------------------------------------------------
DROP TABLE localidades CASCADE;
DROP SEQUENCE localidades_idlocalidad_seq;


CREATE SEQUENCE localidades_idlocalidad_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE localidades
(
	        
    idlocalidad INTEGER DEFAULT nextval('localidades_idlocalidad_seq') NOT NULL,
	        
    idprovincia INTEGER default 0,
	        
    nombre VARCHAR(50),

    PRIMARY KEY (idlocalidad)
);




-----------------------------------------------------------------------------
-- capitulos
-----------------------------------------------------------------------------
DROP TABLE capitulos CASCADE;
DROP SEQUENCE capitulos_idcapitulo_seq;


CREATE SEQUENCE capitulos_idcapitulo_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE capitulos
(
	        
    idcapitulo INTEGER DEFAULT nextval('capitulos_idcapitulo_seq') NOT NULL,
	        
    nombre VARCHAR(150),

    PRIMARY KEY (idcapitulo)
);




-----------------------------------------------------------------------------
-- subcapitulos
-----------------------------------------------------------------------------
DROP TABLE subcapitulos CASCADE;
DROP SEQUENCE subcapitulos_idsubcapitulo_seq;


CREATE SEQUENCE subcapitulos_idsubcapitulo_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE subcapitulos
(
	        
    idsubcapitulo INTEGER DEFAULT nextval('subcapitulos_idsubcapitulo_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    nombre VARCHAR(150),
	        
    idcapitulo INTEGER default 0,

    PRIMARY KEY (idsubcapitulo)
);




-----------------------------------------------------------------------------
-- categorias
-----------------------------------------------------------------------------
DROP TABLE categorias CASCADE;
DROP SEQUENCE categorias_idcategoria_seq;


CREATE SEQUENCE categorias_idcategoria_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE categorias
(
	        
    idcategoria INTEGER DEFAULT nextval('categorias_idcategoria_seq') NOT NULL,
	        
    descripcion VARCHAR(510),

    PRIMARY KEY (idcategoria)
);




-----------------------------------------------------------------------------
-- tipoincidencias
-----------------------------------------------------------------------------
DROP TABLE tipoincidencias CASCADE;
DROP SEQUENCE tipoincidencias_idtipoincidencia_seq;


CREATE SEQUENCE tipoincidencias_idtipoincidencia_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE tipoincidencias
(
	        
    idtipoincidencia INTEGER DEFAULT nextval('tipoincidencias_idtipoincidencia_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    descripcion VARCHAR(150),

    PRIMARY KEY (idtipoincidencia)
);




-----------------------------------------------------------------------------
-- tipomaquinarias
-----------------------------------------------------------------------------
DROP TABLE tipomaquinarias CASCADE;
DROP SEQUENCE tipomaquinarias_idtipomaquinaria_seq;


CREATE SEQUENCE tipomaquinarias_idtipomaquinaria_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE tipomaquinarias
(
	        
    idtipomaquinaria INTEGER DEFAULT nextval('tipomaquinarias_idtipomaquinaria_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    nombre VARCHAR(50),

    PRIMARY KEY (idtipomaquinaria)
);




-----------------------------------------------------------------------------
-- tipocombustibles
-----------------------------------------------------------------------------
DROP TABLE tipocombustibles CASCADE;
DROP SEQUENCE tipocombustibles_idtipocombustible_seq;


CREATE SEQUENCE tipocombustibles_idtipocombustible_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE tipocombustibles
(
	        
    idtipocombustible INTEGER DEFAULT nextval('tipocombustibles_idtipocombustible_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    descripcion VARCHAR(150),
	        
    coste FLOAT default 0,
	        
    fecha VARCHAR(8),

    PRIMARY KEY (idtipocombustible)
);




-----------------------------------------------------------------------------
-- tipoportes
-----------------------------------------------------------------------------
DROP TABLE tipoportes CASCADE;
DROP SEQUENCE tipoportes_idtipoporte_seq;


CREATE SEQUENCE tipoportes_idtipoporte_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE tipoportes
(
	        
    idtipoporte INTEGER DEFAULT nextval('tipoportes_idtipoporte_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    idlocalidad INTEGER default 0,
	        
    descripcion VARCHAR(150),
	        
    coste FLOAT default 0,
	        
    fecha VARCHAR(8),

    PRIMARY KEY (idtipoporte)
);




-----------------------------------------------------------------------------
-- clientes
-----------------------------------------------------------------------------
DROP TABLE clientes CASCADE;
DROP SEQUENCE clientes_idcliente_seq;


CREATE SEQUENCE clientes_idcliente_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE clientes
(
	        
    idcliente INTEGER DEFAULT nextval('clientes_idcliente_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    cif VARCHAR(10),
	        
    nombre VARCHAR(50),
	        
    razonsocial VARCHAR(50),
	        
    contacto VARCHAR(50),
	        
    telefono VARCHAR(9),
	        
    fechaalta VARCHAR(8),
	        
    fechabaja VARCHAR(8),
	        
    idlocalidad INTEGER default 0,
	        
    direccion VARCHAR(50),
	        
    cp VARCHAR(5),
	        
    fax VARCHAR(9),
	        
    movil VARCHAR(9),
	        
    email VARCHAR(50),
	        
    www VARCHAR(50),
	        
    observaciones VARCHAR(500),

    PRIMARY KEY (idcliente)
);




-----------------------------------------------------------------------------
-- obras
-----------------------------------------------------------------------------
DROP TABLE obras CASCADE;
DROP SEQUENCE obras_idobra_seq;


CREATE SEQUENCE obras_idobra_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE obras
(
	        
    idobra INTEGER DEFAULT nextval('obras_idobra_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    nombre VARCHAR(50),
	        
    numerocontrato VARCHAR(10),
	        
    idcliente INTEGER default 0,
	        
    idlocalidad INTEGER default 0,
	        
    fechaalta VARCHAR(8),
	        
    fechacomienzo VARCHAR(8),
	        
    fechafin VARCHAR(8),
	        
    calle VARCHAR(50),
	        
    cp VARCHAR(50),
	        
    jornadas INTEGER default 0,
	        
    observaciones VARCHAR(500),
	        
    importe FLOAT default 0,
	        
    importecalc FLOAT default 0,

    PRIMARY KEY (idobra)
);




-----------------------------------------------------------------------------
-- albaranes
-----------------------------------------------------------------------------
DROP TABLE albaranes CASCADE;
DROP SEQUENCE albaranes_idalbaran_seq;


CREATE SEQUENCE albaranes_idalbaran_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE albaranes
(
	        
    idalbaran INTEGER DEFAULT nextval('albaranes_idalbaran_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    idobra INTEGER default 0,
	        
    fechacomienzo VARCHAR(8),
	        
    fechafin VARCHAR(8),

    PRIMARY KEY (idalbaran)
);




-----------------------------------------------------------------------------
-- lineasalbaran
-----------------------------------------------------------------------------
DROP TABLE lineasalbaran CASCADE;
DROP SEQUENCE lineasalbaran_idlineaalbaran_seq;


CREATE SEQUENCE lineasalbaran_idlineaalbaran_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE lineasalbaran
(
	        
    idlineaalbaran INTEGER DEFAULT nextval('lineasalbaran_idlineaalbaran_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    idalbaran INTEGER default 0,
	        
    descripcion VARCHAR(50),
	        
    importe FLOAT default 0,
	        
    elementoid INTEGER default 0,
	        
    elementotipo VARCHAR(50),

    PRIMARY KEY (idlineaalbaran)
);




-----------------------------------------------------------------------------
-- uejecuciones
-----------------------------------------------------------------------------
DROP TABLE uejecuciones CASCADE;
DROP SEQUENCE uejecuciones_iduejecucion_seq;


CREATE SEQUENCE uejecuciones_iduejecucion_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE uejecuciones
(
	        
    iduejecucion INTEGER DEFAULT nextval('uejecuciones_iduejecucion_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    idobra INTEGER default 0,
	        
    idsubcapitulo INTEGER default 0,
	        
    fechacomienzo VARCHAR(8),
	        
    fechafin VARCHAR(8),
	        
    importe FLOAT default 0,
	        
    horasestimadas FLOAT default 0,
	        
    descripcion VARCHAR(500),
	        
    observaciones VARCHAR(500),
	        
    importecalc FLOAT default 0,

    PRIMARY KEY (iduejecucion)
);




-----------------------------------------------------------------------------
-- operarios
-----------------------------------------------------------------------------
DROP TABLE operarios CASCADE;
DROP SEQUENCE operarios_idoperario_seq;


CREATE SEQUENCE operarios_idoperario_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE operarios
(
	        
    idoperario INTEGER DEFAULT nextval('operarios_idoperario_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    nombre VARCHAR(50),
	        
    apellidouno VARCHAR(50),
	        
    numeross VARCHAR(20),
	        
    telefono VARCHAR(9),
	        
    movil VARCHAR(9),
	        
    externo INTEGER default 0,
	        
    idcategoria INTEGER default 0,
	        
    nif VARCHAR(10),
	        
    apellidodos VARCHAR(50),
	        
    fechaalta VARCHAR(8),
	        
    fechabaja VARCHAR(8),
	        
    direccion VARCHAR(50),
	        
    cp VARCHAR(5),
	        
    idlocalidad INTEGER default 0,
	        
    email VARCHAR(25),
	        
    coste FLOAT default 0,
	        
    observaciones VARCHAR(500),

    PRIMARY KEY (idoperario)
);




-----------------------------------------------------------------------------
-- maquinarias
-----------------------------------------------------------------------------
DROP TABLE maquinarias CASCADE;
DROP SEQUENCE maquinarias_idmaquinaria_seq;


CREATE SEQUENCE maquinarias_idmaquinaria_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE maquinarias
(
	        
    idmaquinaria INTEGER DEFAULT nextval('maquinarias_idmaquinaria_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    bastidor VARCHAR(50),
	        
    nombre VARCHAR(50),
	        
    modelo VARCHAR(50),
	        
    tipo VARCHAR(50),
	        
    alquilado INTEGER default 0,
	        
    subcontratado INTEGER default 0,
	        
    idtipomaquinaria INTEGER default 0,
	        
    matricula VARCHAR(10),
	        
    fechaalta VARCHAR(8),
	        
    fechabaja VARCHAR(8),
	        
    responsable VARCHAR(50),
	        
    costecon FLOAT default 0,
	        
    costesin FLOAT default 0,
	        
    marca VARCHAR(50),
	        
    observaciones VARCHAR(500),

    PRIMARY KEY (idmaquinaria)
);




-----------------------------------------------------------------------------
-- parteso
-----------------------------------------------------------------------------
DROP TABLE parteso CASCADE;
DROP SEQUENCE parteso_idparteo_seq;


CREATE SEQUENCE parteso_idparteo_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE parteso
(
	        
    idparteo INTEGER DEFAULT nextval('parteso_idparteo_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    iduejecucion INTEGER default 0,
	        
    idoperario INTEGER default 0,
	        
    fecha VARCHAR(8),
	        
    horas FLOAT default 0,
	        
    porcentajedto INTEGER default 0,
	        
    dto FLOAT default 0,
	        
    importe FLOAT default 0,
	        
    descripcion VARCHAR(500),
	        
    observaciones VARCHAR(500),
	        
    importesindto FLOAT default 0,
	        
    importecondto FLOAT default 0,
	        
    idalbaran INTEGER default 0,

    PRIMARY KEY (idparteo)
);




-----------------------------------------------------------------------------
-- partesm
-----------------------------------------------------------------------------
DROP TABLE partesm CASCADE;
DROP SEQUENCE partesm_idpartem_seq;


CREATE SEQUENCE partesm_idpartem_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE partesm
(
	        
    idpartem INTEGER DEFAULT nextval('partesm_idpartem_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    iduejecucion INTEGER default 0,
	        
    idmaquinaria INTEGER default 0,
	        
    fecha VARCHAR(8),
	        
    horas FLOAT default 0,
	        
    idtipoporteida INTEGER default 0,
	        
    idtipoportevuelta INTEGER default 0,
	        
    conoperario INTEGER default 0,
	        
    porcentajedto INTEGER default 0,
	        
    dto FLOAT default 0,
	        
    importe FLOAT default 0,
	        
    descripcion VARCHAR(500),
	        
    observaciones VARCHAR(500),
	        
    importeporte FLOAT default 0,
	        
    importesindto FLOAT default 0,
	        
    importecondto FLOAT default 0,
	        
    idalbaran INTEGER default 0,

    PRIMARY KEY (idpartem)
);




-----------------------------------------------------------------------------
-- incidenciaso
-----------------------------------------------------------------------------
DROP TABLE incidenciaso CASCADE;
DROP SEQUENCE incidenciaso_idincidenciao_seq;


CREATE SEQUENCE incidenciaso_idincidenciao_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE incidenciaso
(
	        
    idincidenciao INTEGER DEFAULT nextval('incidenciaso_idincidenciao_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    iduejecucion INTEGER default 0,
	        
    idoperario INTEGER default 0,
	        
    idtipoincidencia INTEGER default 0,
	        
    fecha VARCHAR(8),
	        
    horas FLOAT default 0,
	        
    porcentajedto INTEGER default 0,
	        
    dto FLOAT default 0,
	        
    importe FLOAT default 0,
	        
    descripcion VARCHAR(500),
	        
    observaciones VARCHAR(500),
	        
    importesindto FLOAT default 0,
	        
    importecondto FLOAT default 0,
	        
    idalbaran INTEGER default 0,

    PRIMARY KEY (idincidenciao)
);




-----------------------------------------------------------------------------
-- incidenciasm
-----------------------------------------------------------------------------
DROP TABLE incidenciasm CASCADE;
DROP SEQUENCE incidenciasm_idincidenciam_seq;


CREATE SEQUENCE incidenciasm_idincidenciam_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE incidenciasm
(
	        
    idincidenciam INTEGER DEFAULT nextval('incidenciasm_idincidenciam_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    iduejecucion INTEGER default 0,
	        
    idmaquinaria INTEGER default 0,
	        
    idtipoincidencia INTEGER default 0,
	        
    fecha VARCHAR(8),
	        
    horas FLOAT default 0,
	        
    conoperario INTEGER default 0,
	        
    porcentajedto INTEGER default 0,
	        
    dto FLOAT default 0,
	        
    importe FLOAT default 0,
	        
    kilometros FLOAT default 0,
	        
    tonelaje FLOAT default 0,
	        
    descripcion VARCHAR(500),
	        
    observaciones VARCHAR(500),
	        
    importesindto FLOAT default 0,
	        
    importecondto FLOAT default 0,
	        
    idalbaran INTEGER default 0,

    PRIMARY KEY (idincidenciam)
);




-----------------------------------------------------------------------------
-- alquileres
-----------------------------------------------------------------------------
DROP TABLE alquileres CASCADE;
DROP SEQUENCE alquileres_idalquiler_seq;


CREATE SEQUENCE alquileres_idalquiler_seq INCREMENT BY 1 START WITH 1 NO MAXVALUE NO CYCLE;

CREATE TABLE alquileres
(
	        
    idalquiler INTEGER DEFAULT nextval('alquileres_idalquiler_seq') NOT NULL,
	        
    referencia VARCHAR(50),
	        
    iduejecucion INTEGER default 0,
	        
    idmaquinaria INTEGER default 0,
	        
    idtipoporteida INTEGER default 0,
	        
    idtipoportevuelta INTEGER default 0,
	        
    idtipocombustible INTEGER default 0,
	        
    seguro INTEGER default 0,
	        
    conoperario INTEGER default 0,
	        
    fechaentrada VARCHAR(8),
	        
    fechasalida VARCHAR(8),
	        
    difdias FLOAT default 0,
	        
    horametroe FLOAT default 0,
	        
    horametros FLOAT default 0,
	        
    testimado FLOAT default 0,
	        
    paralizacion FLOAT default 0,
	        
    difcombustible FLOAT default 0,
	        
    porcentajedto INTEGER default 0,
	        
    dto FLOAT default 0,
	        
    importe FLOAT default 0,
	        
    duracion FLOAT default 0,
	        
    importecombustible FLOAT default 0,
	        
    importeporte FLOAT default 0,
	        
    importesindto FLOAT default 0,
	        
    importecondto FLOAT default 0,
	        
    idalbaran INTEGER default 0,

    PRIMARY KEY (idalquiler)
);




----------------------------------------------------------------------
-- alquileres
----------------------------------------------------------------------



----------------------------------------------------------------------
-- provincias
----------------------------------------------------------------------


ALTER TABLE localidades
    ADD CONSTRAINT localidades_FK_1 FOREIGN KEY (idprovincia)
    REFERENCES provincias (idprovincia)
;

----------------------------------------------------------------------
-- localidades
----------------------------------------------------------------------



----------------------------------------------------------------------
-- capitulos
----------------------------------------------------------------------


ALTER TABLE subcapitulos
    ADD CONSTRAINT subcapitulos_FK_1 FOREIGN KEY (idcapitulo)
    REFERENCES capitulos (idcapitulo)
;

----------------------------------------------------------------------
-- subcapitulos
----------------------------------------------------------------------



----------------------------------------------------------------------
-- categorias
----------------------------------------------------------------------



----------------------------------------------------------------------
-- tipoincidencias
----------------------------------------------------------------------



----------------------------------------------------------------------
-- tipomaquinarias
----------------------------------------------------------------------



----------------------------------------------------------------------
-- tipocombustibles
----------------------------------------------------------------------


ALTER TABLE tipoportes
    ADD CONSTRAINT tipoportes_FK_1 FOREIGN KEY (idlocalidad)
    REFERENCES localidades (idlocalidad)
;

----------------------------------------------------------------------
-- tipoportes
----------------------------------------------------------------------


ALTER TABLE clientes
    ADD CONSTRAINT clientes_FK_1 FOREIGN KEY (idlocalidad)
    REFERENCES localidades (idlocalidad)
;

----------------------------------------------------------------------
-- clientes
----------------------------------------------------------------------


ALTER TABLE obras
    ADD CONSTRAINT obras_FK_1 FOREIGN KEY (idcliente)
    REFERENCES clientes (idcliente)
;
ALTER TABLE obras
    ADD CONSTRAINT obras_FK_2 FOREIGN KEY (idlocalidad)
    REFERENCES localidades (idlocalidad)
;

----------------------------------------------------------------------
-- obras
----------------------------------------------------------------------


ALTER TABLE albaranes
    ADD CONSTRAINT albaranes_FK_1 FOREIGN KEY (idobra)
    REFERENCES obras (idobra)
;

----------------------------------------------------------------------
-- albaranes
----------------------------------------------------------------------


ALTER TABLE lineasalbaran
    ADD CONSTRAINT lineasalbaran_FK_1 FOREIGN KEY (idalbaran)
    REFERENCES albaranes (idalbaran)
    ON UPDATE CASCADE
    ON DELETE CASCADE
;

----------------------------------------------------------------------
-- lineasalbaran
----------------------------------------------------------------------


ALTER TABLE uejecuciones
    ADD CONSTRAINT uejecuciones_FK_1 FOREIGN KEY (idobra)
    REFERENCES obras (idobra)
;
ALTER TABLE uejecuciones
    ADD CONSTRAINT uejecuciones_FK_2 FOREIGN KEY (idsubcapitulo)
    REFERENCES subcapitulos (idsubcapitulo)
;

----------------------------------------------------------------------
-- uejecuciones
----------------------------------------------------------------------


ALTER TABLE operarios
    ADD CONSTRAINT operarios_FK_1 FOREIGN KEY (idcategoria)
    REFERENCES categorias (idcategoria)
;
ALTER TABLE operarios
    ADD CONSTRAINT operarios_FK_2 FOREIGN KEY (idlocalidad)
    REFERENCES localidades (idlocalidad)
;

----------------------------------------------------------------------
-- operarios
----------------------------------------------------------------------


ALTER TABLE maquinarias
    ADD CONSTRAINT maquinarias_FK_1 FOREIGN KEY (idtipomaquinaria)
    REFERENCES tipomaquinarias (idtipomaquinaria)
;

----------------------------------------------------------------------
-- maquinarias
----------------------------------------------------------------------


ALTER TABLE parteso
    ADD CONSTRAINT parteso_FK_1 FOREIGN KEY (idoperario)
    REFERENCES operarios (idoperario)
;
ALTER TABLE parteso
    ADD CONSTRAINT parteso_FK_2 FOREIGN KEY (iduejecucion)
    REFERENCES uejecuciones (iduejecucion)
;

----------------------------------------------------------------------
-- parteso
----------------------------------------------------------------------


ALTER TABLE partesm
    ADD CONSTRAINT partesm_FK_1 FOREIGN KEY (idmaquinaria)
    REFERENCES maquinarias (idmaquinaria)
;
ALTER TABLE partesm
    ADD CONSTRAINT partesm_FK_2 FOREIGN KEY (iduejecucion)
    REFERENCES uejecuciones (iduejecucion)
;
ALTER TABLE partesm
    ADD CONSTRAINT partesm_FK_3 FOREIGN KEY (idtipoporteida)
    REFERENCES tipoportes (idtipoporte)
;
ALTER TABLE partesm
    ADD CONSTRAINT partesm_FK_4 FOREIGN KEY (idtipoportevuelta)
    REFERENCES tipoportes (idtipoporte)
;

----------------------------------------------------------------------
-- partesm
----------------------------------------------------------------------


ALTER TABLE incidenciaso
    ADD CONSTRAINT incidenciaso_FK_1 FOREIGN KEY (idoperario)
    REFERENCES operarios (idoperario)
;
ALTER TABLE incidenciaso
    ADD CONSTRAINT incidenciaso_FK_2 FOREIGN KEY (idtipoincidencia)
    REFERENCES tipoincidencias (idtipoincidencia)
;
ALTER TABLE incidenciaso
    ADD CONSTRAINT incidenciaso_FK_3 FOREIGN KEY (iduejecucion)
    REFERENCES uejecuciones (iduejecucion)
;

----------------------------------------------------------------------
-- incidenciaso
----------------------------------------------------------------------


ALTER TABLE incidenciasm
    ADD CONSTRAINT incidenciasm_FK_1 FOREIGN KEY (idmaquinaria)
    REFERENCES maquinarias (idmaquinaria)
;
ALTER TABLE incidenciasm
    ADD CONSTRAINT incidenciasm_FK_2 FOREIGN KEY (idtipoincidencia)
    REFERENCES tipoincidencias (idtipoincidencia)
;
ALTER TABLE incidenciasm
    ADD CONSTRAINT incidenciasm_FK_3 FOREIGN KEY (iduejecucion)
    REFERENCES uejecuciones (iduejecucion)
;

----------------------------------------------------------------------
-- incidenciasm
----------------------------------------------------------------------


ALTER TABLE alquileres
    ADD CONSTRAINT alquileres_FK_1 FOREIGN KEY (idmaquinaria)
    REFERENCES maquinarias (idmaquinaria)
;
ALTER TABLE alquileres
    ADD CONSTRAINT alquileres_FK_2 FOREIGN KEY (iduejecucion)
    REFERENCES uejecuciones (iduejecucion)
;
ALTER TABLE alquileres
    ADD CONSTRAINT alquileres_FK_3 FOREIGN KEY (idtipoporteida)
    REFERENCES tipoportes (idtipoporte)
;
ALTER TABLE alquileres
    ADD CONSTRAINT alquileres_FK_4 FOREIGN KEY (idtipoportevuelta)
    REFERENCES tipoportes (idtipoporte)
;
ALTER TABLE alquileres
    ADD CONSTRAINT alquileres_FK_5 FOREIGN KEY (idtipocombustible)
    REFERENCES tipocombustibles (idtipocombustible)
;
