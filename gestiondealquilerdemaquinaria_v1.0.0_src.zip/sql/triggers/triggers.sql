-- Function: trgalquileresinsert()

-- DROP FUNCTION trgalquileresinsert();

CREATE OR REPLACE FUNCTION trgalquileresinsert()
  RETURNS "trigger" AS
$BODY$DECLARE
Procesar boolean:=false;
NA double precision:=0;
NB double precision:=0;
Par double precision:=0;
Cos double precision:=0;
CosCon double precision:=0;
CosSin double precision:=0;
CosPorte double precision:=0;
CosPorteIda double precision:=0;
CosPorteVuelta double precision:=0;
CosComb double precision:=0;
ConOp double precision:=0;
Dur double precision:=0;
ISD double precision:=0;
ISeg double precision:=0;
ICD double precision:=0;
Dcto double precision:=0;
PorcDcto double precision:=0;
BEGIN 
select maquinarias.costecon into CosCon from maquinarias inner join alquileres on maquinarias.idmaquinaria = alquileres.idmaquinaria where idalquiler = NEW.idalquiler;
select maquinarias.costesin into CosSin from maquinarias inner join alquileres on maquinarias.idmaquinaria = alquileres.idmaquinaria where idalquiler = NEW.idalquiler;
select tipoportes.coste into CosPorteIda from tipoportes inner join alquileres on tipoportes.idtipoporte = alquileres.idtipoporteida where idalquiler = NEW.idalquiler;
select tipoportes.coste into CosPorteVuelta from tipoportes inner join alquileres on tipoportes.idtipoporte = alquileres.idtipoportevuelta where idalquiler = NEW.idalquiler;
select tipocombustibles.coste into CosComb from tipocombustibles inner join alquileres on tipocombustibles.idtipocombustible = alquileres.idtipocombustible where idalquiler = NEW.idalquiler;

if (NEW.FECHAENTRADA is null) or (NEW.HORAMETROE is null) or (NEW.FECHAENTRADA = '') or (NEW.HORAMETROE = 0) then 
	Procesar := false; 
elseif (TG_OP = 'INSERT') then
	Procesar := true;
elseif (TG_OP = 'UPDATE') then
	if (OLD.FECHAENTRADA = '') or (OLD.FECHAENTRADA is null) then 
		OLD.FECHAENTRADA := '19500101'; 
	end if;
	if (NEW.paralizacion <> OLD.paralizacion) or (NEW.idmaquinaria <> OLD.idmaquinaria) or (NEW.idtipoporteida <> OLD.idtipoporteida) or (NEW.idtipoportevuelta <> OLD.idtipoportevuelta) or (NEW.idtipocombustible <> OLD.idtipocombustible) or (NEW.difcombustible <> OLD.difcombustible) or (NEW.difdias <> OLD.difdias) or (NEW.HORAMETROE <> OLD.HORAMETROE) or (NEW.HORAMETROS <> OLD.HORAMETROS) or (NEW.CONOPERARIO <> OLD.CONOPERARIO)  or (NEW.SEGURO <> OLD.SEGURO)  or (NEW.DTO <> OLD.DTO) or (NEW.porcentajedto <> OLD.porcentajedto) then
		Procesar := true;
	end if;
end if;

if Procesar = true then
	NA := NEW.HORAMETROE - NEW.HORAMETROS;
	NB := NEW.DIFDIAS;
	Par := NEW.Paralizacion;
	Dcto := NEW.dto;
	PorcDcto := NEW.porcentajedto;
	if (NA < NB*8) then
		Dur= NB*8 - Par;
	else
		Dur= NA - Par;
	end if;	
	if (NEW.conoperario = 1) then
		Cos = CosCon;
	else
		Cos = CosSin;
	end if;
	CosComb = CosComb * NEW.difcombustible;
	ISeg= Cos*Dur;
	if (NEW.seguro = 1) then
		ISD = ISeg + ISeg*3/100;
	else
		ISD = ISeg;
	end if;
	if (PorcDcto = 1) then
		ICD= ISD - ISD*Dcto/100;
	else
		ICD= ISD - Dcto;
	end if;
	CosPorte = CosPorteIda + CosPorteVuelta;
	update alquileres set duracion= Dur, importesindto= ISD, importecondto= ICD, importecombustible= CosComb, importeporte= CosPorte where idalquiler = NEW.idalquiler;
end if;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgalquileresinsert() OWNER TO "avebieUser";

-- Trigger: trg_alquileresinsert on alquileres

-- DROP TRIGGER trg_alquileresinsert ON alquileres;

CREATE TRIGGER trg_alquileresinsert
  AFTER INSERT OR UPDATE
  ON alquileres
  FOR EACH ROW
  EXECUTE PROCEDURE trgalquileresinsert();
  
  

-- Function: trgpartesoinsert()

-- DROP FUNCTION trgpartesoinsert();

CREATE OR REPLACE FUNCTION trgpartesoinsert()
  RETURNS "trigger" AS
$BODY$DECLARE
Procesar boolean:=false;
Cos double precision:=0;
ISD double precision:=0;
ICD double precision:=0;
Dcto double precision:=0;
PorcDcto double precision:=0;
BEGIN 
select operarios.coste into Cos from operarios inner join parteso on operarios.idoperario = parteso.idoperario where idparteo = NEW.idparteo;

if (TG_OP = 'INSERT') then
	Procesar := true;
elseif (TG_OP = 'UPDATE') and ((NEW.DTO <> OLD.DTO) or (NEW.porcentajedto <> OLD.porcentajedto) or (NEW.idoperario <> OLD.idoperario)  or (NEW.horas <> OLD.horas)) then
	Procesar := true;
end if;

if Procesar = true then
	Dcto := NEW.dto;
	PorcDcto := NEW.porcentajedto;
	ISD= Cos*NEW.horas;
	if (PorcDcto = 1) then
		ICD= ISD - ISD*Dcto/100;
	else
		ICD= ISD - Dcto;
	end if;
	update parteso set importesindto= ISD, importecondto= ICD where idparteo = NEW.idparteo;
end if;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgpartesoinsert() OWNER TO "avebieUser";

-- Trigger: trg_partesoinsert on parteso

-- DROP TRIGGER trg_partesoinsert ON parteso;

CREATE TRIGGER trg_partesoinsert
  AFTER INSERT OR UPDATE
  ON parteso
  FOR EACH ROW
  EXECUTE PROCEDURE trgpartesoinsert();
  
  
  
-- Function: trgpartesminsert()

-- DROP FUNCTION trgpartesminsert();

CREATE OR REPLACE FUNCTION trgpartesminsert()
  RETURNS "trigger" AS
$BODY$DECLARE
Procesar boolean:=false;
CosSin double precision:=0;
CosCon double precision:=0;
Cos double precision:=0;
CosPorte double precision:=0;
CosPorteIda double precision:=0;
CosPorteVuelta double precision:=0;
ISD double precision:=0;
ICD double precision:=0;
Dcto double precision:=0;
PorcDcto double precision:=0;
BEGIN 
select maquinarias.costesin into CosSin from maquinarias inner join partesm on maquinarias.idmaquinaria = partesm.idmaquinaria where idpartem = NEW.idpartem;
select maquinarias.costecon into CosCon from maquinarias inner join partesm on maquinarias.idmaquinaria = partesm.idmaquinaria where idpartem = NEW.idpartem;
select tipoportes.coste into CosPorteIda from tipoportes inner join partesm on tipoportes.idtipoporte = partesm.idtipoporteida where idpartem = NEW.idpartem;
select tipoportes.coste into CosPorteVuelta from tipoportes inner join partesm on tipoportes.idtipoporte = partesm.idtipoportevuelta where idpartem = NEW.idpartem;

if (TG_OP = 'INSERT') then
	Procesar := true;
elseif (TG_OP = 'UPDATE') and ((NEW.DTO <> OLD.DTO) or (NEW.porcentajedto <> OLD.porcentajedto) or (NEW.idmaquinaria <> OLD.idmaquinaria)or (NEW.idtipoporteida <> OLD.idtipoporteida) or (NEW.idtipoportevuelta <> OLD.idtipoportevuelta)  or (NEW.horas <> OLD.horas) or (NEW.CONOPERARIO <> OLD.CONOPERARIO)) then
	Procesar := true;
end if;

if Procesar = true then
	Dcto := NEW.dto;
	PorcDcto := NEW.porcentajedto;
	if (NEW.conoperario = 1) then
		Cos = CosCon;
	else
		Cos = CosSin;
	end if;	
	ISD= Cos*NEW.horas;
	if (PorcDcto = 1) then
		ICD= ISD - ISD*Dcto/100;
	else
		ICD= ISD - Dcto;
	end if;
	CosPorte = CosPorteIda + CosPorteVuelta;
	update partesm set importesindto= ISD, importecondto= ICD, importeporte= CosPorte where idpartem = NEW.idpartem;
end if;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgpartesminsert() OWNER TO "avebieUser";

-- Trigger: trg_partesminsert on partesm

-- DROP TRIGGER trg_partesminsert ON partesm;

CREATE TRIGGER trg_partesminsert
  AFTER INSERT OR UPDATE
  ON partesm
  FOR EACH ROW
  EXECUTE PROCEDURE trgpartesminsert();    
  
  
-- Function: trgincidenciasoinsert()

-- DROP FUNCTION trgincidenciasoinsert();

CREATE OR REPLACE FUNCTION trgincidenciasoinsert()
  RETURNS "trigger" AS
$BODY$DECLARE
Procesar boolean:=false;
Cos double precision:=0;
ISD double precision:=0;
ICD double precision:=0;
Dcto double precision:=0;
PorcDcto double precision:=0;
BEGIN 
select operarios.coste into Cos from operarios inner join incidenciaso on operarios.idoperario = incidenciaso.idoperario where idincidenciao = NEW.idincidenciao;

if (TG_OP = 'INSERT') then
	Procesar := true;
elseif (TG_OP = 'UPDATE') and ((NEW.DTO <> OLD.DTO) or (NEW.porcentajedto <> OLD.porcentajedto) or (NEW.idoperario <> OLD.idoperario)  or (NEW.horas <> OLD.horas)) then
	Procesar := true;
end if;

if Procesar = true then
	Dcto := NEW.dto;
	PorcDcto := NEW.porcentajedto;
	ISD= Cos*NEW.horas;
	if (PorcDcto = 1) then
		ICD= ISD - ISD*Dcto/100;
	else
		ICD= ISD - Dcto;
	end if;
	update incidenciaso set importesindto= ISD, importecondto= ICD where idincidenciao = NEW.idincidenciao;
end if;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgincidenciasoinsert() OWNER TO "avebieUser";

-- Trigger: trg_incidenciasoinsert on incidenciaso

-- DROP TRIGGER trg_incidenciasoinsert ON incidenciaso;

CREATE TRIGGER trg_incidenciasoinsert
  AFTER INSERT OR UPDATE
  ON incidenciaso
  FOR EACH ROW
  EXECUTE PROCEDURE trgincidenciasoinsert();
  
  
  
-- Function: trgincidenciasminsert()

-- DROP FUNCTION trgincidenciasminsert();

CREATE OR REPLACE FUNCTION trgincidenciasminsert()
  RETURNS "trigger" AS
$BODY$DECLARE
Procesar boolean:=false;
CosSin double precision:=0;
CosCon double precision:=0;
Cos double precision:=0;
ISD double precision:=0;
ICD double precision:=0;
Dcto double precision:=0;
PorcDcto double precision:=0;
BEGIN 
select maquinarias.costesin into CosSin from maquinarias inner join incidenciasm on maquinarias.idmaquinaria = incidenciasm.idmaquinaria where idincidenciam = NEW.idincidenciam;
select maquinarias.costecon into CosCon from maquinarias inner join incidenciasm on maquinarias.idmaquinaria = incidenciasm.idmaquinaria where idincidenciam = NEW.idincidenciam;

if (TG_OP = 'INSERT') then
	Procesar := true;
elseif (TG_OP = 'UPDATE') and ((NEW.DTO <> OLD.DTO) or (NEW.porcentajedto <> OLD.porcentajedto) or (NEW.idmaquinaria <> OLD.idmaquinaria)  or (NEW.horas <> OLD.horas) or (NEW.CONOPERARIO <> OLD.CONOPERARIO)) then
	Procesar := true;
end if;

if Procesar = true then
	Dcto := NEW.dto;
	PorcDcto := NEW.porcentajedto;
	if (NEW.conoperario = 1) then
		Cos = CosCon;
	else
		Cos = CosSin;
	end if;	
	ISD= Cos*NEW.horas;
	if (PorcDcto = 1) then
		ICD= ISD - ISD*Dcto/100;
	else
		ICD= ISD - Dcto;
	end if;
	update incidenciasm set importesindto= ISD, importecondto= ICD where idincidenciam = NEW.idincidenciam;
end if;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgincidenciasminsert() OWNER TO "avebieUser";

-- Trigger: trg_incidenciasminsert on incidenciasm

-- DROP TRIGGER trg_incidenciasminsert ON incidenciasm;

CREATE TRIGGER trg_incidenciasminsert
  AFTER INSERT OR UPDATE
  ON incidenciasm
  FOR EACH ROW
  EXECUTE PROCEDURE trgincidenciasminsert();   
  
  
  
-- Function: trgalquileresmaquinariaalquilado()

-- DROP FUNCTION trgalquileresmaquinariaalquilado();

CREATE OR REPLACE FUNCTION trgalquileresmaquinariaalquilado()
  RETURNS "trigger" AS
$BODY$DECLARE

Numero integer:=0;
BEGIN 
select count(idalquiler) into Numero from alquileres inner join maquinarias on alquileres.idmaquinaria = maquinarias.idmaquinaria where idalquiler = NEW.idalquiler and (alquileres.fechaentrada is null or alquileres.horametroe=0);

	if (Numero > 0) then
		update maquinarias set alquilado= 1 where maquinarias.idmaquinaria = NEW.idmaquinaria;
	else
		update maquinarias set alquilado= 0 where maquinarias.idmaquinaria = NEW.idmaquinaria;
	end if;


return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgalquileresmaquinariaalquilado() OWNER TO "avebieUser";

-- Trigger: trg_alquileresmaquinariaalquilado on alquileres

-- DROP TRIGGER trg_alquileresmaquinariaalquilado ON alquileres;

CREATE TRIGGER trg_alquileresmaquinariaalquilado
  AFTER INSERT OR UPDATE
  ON alquileres
  FOR EACH ROW
  EXECUTE PROCEDURE trgalquileresmaquinariaalquilado();  
  
  
-- Function: trglineasalbarandelete()

-- DROP FUNCTION trglineasalbarandelete();

CREATE OR REPLACE FUNCTION trglineasalbarandelete()
  RETURNS "trigger" AS
$BODY$DECLARE

BEGIN

if OLD.elementotipo = 'Parteso' then
	update parteso set idalbaran=0 where idparteo=OLD.elementoid;
end if;
if OLD.elementotipo = 'Partesm' then
	update partesm set idalbaran=0 where idpartem=OLD.elementoid;
end if;
if OLD.elementotipo = 'Incidenciaso' then
	update incidenciaso set idalbaran=0 where idincidenciao=OLD.elementoid;
end if;
if OLD.elementotipo = 'Incidenciasm' then
	update incidenciasm set idalbaran=0 where idincidenciam=OLD.elementoid;
end if;
if OLD.elementotipo = 'Alquileres' then
	update alquileres set idalbaran=0 where idalquiler=OLD.elementoid;
end if;

RETURN NEW;
END;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trglineasalbarandelete() OWNER TO "avebieUser";

-- Trigger: trg_lineasalbarandelete on lineasalbaran

-- DROP TRIGGER trg_lineasalbarandelete ON lineasalbaran;

CREATE TRIGGER trg_lineasalbarandelete
  AFTER DELETE
  ON lineasalbaran
  FOR EACH ROW
  EXECUTE PROCEDURE trglineasalbarandelete();  
  
  
-- Function: trgueimporte()

-- DROP FUNCTION trgueimporte();

CREATE OR REPLACE FUNCTION trgueimporte()
  RETURNS "trigger" AS
$BODY$DECLARE

SumAlquileres double precision:=0;
SumParteso double precision:=0;
SumPartesm double precision:=0;
SumIncidenciaso double precision:=0;
SumIncidenciasm double precision:=0;
SumTotal double precision:=0;
Idue integer:=0;

BEGIN 
if (TG_OP = 'DELETE') then
	Idue := OLD.iduejecucion;
else
	Idue := NEW.iduejecucion;
end if;

select sum(alquileres.importe) into SumAlquileres from alquileres inner join uejecuciones on alquileres.iduejecucion = uejecuciones.iduejecucion where alquileres.iduejecucion = Idue;
select sum(parteso.importe) into SumParteso from parteso inner join uejecuciones on parteso.iduejecucion = uejecuciones.iduejecucion where parteso.iduejecucion = Idue;
select sum(partesm.importe) into SumPartesm from partesm inner join uejecuciones on partesm.iduejecucion = uejecuciones.iduejecucion where partesm.iduejecucion = Idue;
select sum(incidenciaso.importe) into SumIncidenciaso from incidenciaso inner join uejecuciones on incidenciaso.iduejecucion = uejecuciones.iduejecucion where incidenciaso.iduejecucion = Idue;
select sum(incidenciasm.importe) into SumIncidenciasm from incidenciasm inner join uejecuciones on incidenciasm.iduejecucion = uejecuciones.iduejecucion where incidenciasm.iduejecucion = Idue;
if (SumAlquileres > 0) then
	SumTotal = SumTotal +SumAlquileres;
end if;
if (SumParteso > 0) then
	SumTotal = SumTotal +SumParteso;
end if;
if (SumPartesm > 0) then
	SumTotal = SumTotal +SumPartesm;
end if;
if (SumIncidenciaso > 0) then
	SumTotal = SumTotal -SumIncidenciaso;
end if;
if (SumIncidenciasm > 0) then
	SumTotal = SumTotal -SumIncidenciasm;
end if;

update uejecuciones set importecalc= SumTotal where uejecuciones.iduejecucion = Idue;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgueimporte() OWNER TO "avebieUser";

-- Trigger: trg_alquileresueimporte on alquileres

-- DROP TRIGGER trg_alquileresueimporte ON alquileres;

CREATE TRIGGER trg_alquileresueimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON alquileres
  FOR EACH ROW
  EXECUTE PROCEDURE trgueimporte();   
  
-- Trigger: trg_partesoueimporte on parteso

-- DROP TRIGGER trg_partesoueimporte ON parteso;

CREATE TRIGGER trg_partesoueimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON parteso
  FOR EACH ROW
  EXECUTE PROCEDURE trgueimporte();   
  
-- Trigger: trg_partesmueimporte on partesm

-- DROP TRIGGER trg_partesmueimporte ON partesm;

CREATE TRIGGER trg_partesmueimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON partesm
  FOR EACH ROW
  EXECUTE PROCEDURE trgueimporte();   
  
-- Trigger: trg_incidenciasoueimporte on parteso

-- DROP TRIGGER trg_incidenciasoueimporte ON incidenciaso;

CREATE TRIGGER trg_incidenciasoueimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON incidenciaso
  FOR EACH ROW
  EXECUTE PROCEDURE trgueimporte();   
  
-- Trigger: trg_incidenciasmueimporte on incidenciasm

-- DROP TRIGGER trg_incidenciasmueimporte ON incidenciasm;

CREATE TRIGGER trg_incidenciasmueimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON incidenciasm
  FOR EACH ROW
  EXECUTE PROCEDURE trgueimporte();   
  
  
  
-- Function: trgobrasimporte()

-- DROP FUNCTION trgobrasimporte();

CREATE OR REPLACE FUNCTION trgobrasimporte()
  RETURNS "trigger" AS
$BODY$DECLARE

SumTotal double precision:=0;
SumObras double precision:=0;
Idue integer:=0;

BEGIN 
if (TG_OP = 'DELETE') then
	Idue := OLD.idobra;
else
	Idue := NEW.idobra;
end if;

select sum(uejecuciones.importecalc) into SumObras from uejecuciones inner join obras on uejecuciones.idobra = obras.idobra where uejecuciones.idobra = Idue;

if (SumObras > 0) then
	SumTotal = SumTotal +SumObras;
end if;

update obras set importecalc= SumTotal where obras.idobra = Idue;

return NEW;
end;$BODY$
  LANGUAGE 'plpgsql' VOLATILE;
ALTER FUNCTION trgobrasimporte() OWNER TO "avebieUser";

-- Trigger: trg_obrasimporte on uejecuciones

-- DROP TRIGGER trg_obrasimporte ON uejecuciones;  

CREATE TRIGGER trg_obrasimporte
  AFTER INSERT OR UPDATE OR DELETE
  ON uejecuciones
  FOR EACH ROW
  EXECUTE PROCEDURE trgobrasimporte();   