function extrasNuevoFormulario(){
	if (document.getElementById("maquinarias.IDMAQUINARIA"))
		asignarChange(document.getElementById("maquinarias.IDTIPOMAQUINARIA"),"cambioMaqImp()");
	if (document.getElementById("alquileres.IDALQUILER")){
		var elNota = crearNota();
		document.getElementById("div_nuevo_cabecera").appendChild(elNota);
	}		
}
function extrasEdicionGrid(){
	if (document.getElementById("titulo_Lineasalbaran"))
		document.getElementById("link_nuevo").style.display = "none";
	if (document.getElementById("titulo_Tipoportes")){
		// crar link 'actualizar costes'	
		var spanLink = document.createElement("span");
		spanLink.id="spanLink";
		Element.addClassName(spanLink,"spanLink");
		var imgGenerar = document.createElement("img");
		imgGenerar.src = 'img/recalcular.gif';
		imgGenerar.alt = 'Actualizar costes';
		Element.addClassName(imgGenerar,"imagenCentrada");		
		var aInforme = document.createElement("a");
		aInforme.href = "#";
		aInforme.appendChild(imgGenerar);
		aInforme.appendChild(document.createTextNode(" Actualizar costes"));
		asignarFuncion(aInforme,"actualizarCostes()");
		spanLink.appendChild(aInforme);	
		
		var divActCostes = crearDiv();
		spanLink.appendChild(divActCostes);
		
		document.getElementById("titulo_Tipoportes").parentNode.insertBefore(spanLink,document.getElementById("titulo_Tipoportes").nextSibling);
	}
}
function extrasEdicionFormulario(originalRequest){
	anadirElemento('parteso.IMPORTE','recalcularImporteParteso()');
	anadirElemento('partesm.IMPORTE','recalcularImportePartesm()');
	anadirElemento('incidenciaso.IMPORTE','recalcularImporteIncidenciaso()');
	anadirElemento('incidenciasm.IMPORTE','recalcularImporteIncidenciasm()');
	anadirElemento('alquileres.IMPORTE','recalcularImporteAlquileres()');
	if (document.getElementById("maquinarias.IDMAQUINARIA")){
		if (originalRequest.responseXML.getElementsByTagName('IdtipomaquinariaMaquinariasParsed')[0].firstChild.nodeValue.indexOf("2-IMPLEMENTO") != -1){
			document.getElementById("maquinarias.MATRICULA").parentNode.style.display = "none";
			document.getElementById("maquinarias.MARCA").parentNode.style.width = "750px";
			document.getElementById("maquinarias.BASTIDOR").parentNode.firstChild.nodeValue = "n� serie ";
		}
		asignarChange(document.getElementById("maquinarias.IDTIPOMAQUINARIA"),"cambioMaqImp()");
	}
	if (document.getElementById("albaranes.IDALBARAN")){
		// crar link 'generar lineas'	
		var spanLink = document.createElement("span");
		spanLink.id="spanLink";
		Element.addClassName(spanLink,"spanLink");
		var imgGenerar = document.createElement("img");
		imgGenerar.src = 'img/4.gif';
		imgGenerar.alt = 'Generar lineas de albar�n';
		Element.addClassName(imgGenerar,"imagenCentrada");		
		var aInforme = document.createElement("a");
		aInforme.href = "#";
		aInforme.appendChild(imgGenerar);
		aInforme.appendChild(document.createTextNode(" generar lineas"));
		asignarFuncion(aInforme,"funcGenerarLineas()");
		spanLink.appendChild(aInforme);	
		var element = document.getElementById("imprimir_Albaranes_0");
		element.appendChild(spanLink);
		// dejar los campos como NO EDITABLES	
		document.getElementById("albaranes.REFERENCIA").parentNode.style.display = "none";	
		document.getElementById("albaranes.IDOBRA").parentNode.parentNode.style.display = "none";	
		document.getElementById("albaranes.FECHACOMIENZO").parentNode.style.display = "none";	
		document.getElementById("albaranes.FECHAFIN").parentNode.style.display = "none";
        	var resultXML=originalRequest.responseXML;	
		var strRef = "Referencia: " + resultXML.getElementsByTagName('ReferenciaAlbaranesParsed')[0].firstChild.nodeValue;
		var sel = parseInt(resultXML.getElementsByTagName('IdobraAlbaranesParsed')[0].firstChild.nodeValue);
		//var strObra = document.getElementById("albaranes.IDOBRA").options[sel].text;
		strObra = "obra: " + sel;
		strFI = "fecha inicio: " + resultXML.getElementsByTagName('FechacomienzoAlbaranesParsed')[0].firstChild.nodeValue;
		strFF = "fecha fin: " + resultXML.getElementsByTagName('FechafinAlbaranesParsed')[0].firstChild.nodeValue;
		var divRef=document.createElement("div");
		divRef.innerHTML = strRef;
		var divObra=document.createElement("div");
		divObra.innerHTML = strObra;
		var divFI=document.createElement("div");
		divFI.innerHTML = strFI;
		var divFF=document.createElement("div");
		divFF.innerHTML = strFF;						
		document.getElementById("albaranes.IDALBARAN").parentNode.parentNode.appendChild(divRef);
		document.getElementById("albaranes.IDALBARAN").parentNode.parentNode.appendChild(divObra);
		document.getElementById("albaranes.IDALBARAN").parentNode.parentNode.appendChild(divFI);
		document.getElementById("albaranes.IDALBARAN").parentNode.parentNode.appendChild(divFF);
	}
	if (document.getElementById("alquileres.IDALQUILER")){
		var elNota = crearNota();
		document.getElementById("imprimir_Alquileres_0").appendChild(elNota);
	}
}

/////

function anadirElemento(elem,func){
	if (document.getElementById(elem)){
		var recalculo = crearAImg(elem);
		asignarFuncion(recalculo,func);
		var element = document.getElementById(elem);
		Element.addClassName(element,"cajaFecha");
		element.parentNode.appendChild(recalculo);//.insertBefore(recalculo,element);
	}
}

function crearAImg(elem){
	var recalculo = document.createElement("a");
	recalculo.href = "#";
	var imgRecalculo = document.createElement("img");
	var element = document.getElementById(elem);
	if (parseFloat(element.value) == 0)
	{
		imgRecalculo.src = 'img/recalcular2.gif';
		imgRecalculo.alt = '!Cuidado!! El valor actual es de 0';
	}
	else
	{
		imgRecalculo.src = 'img/recalcular.gif';
		imgRecalculo.alt = 'recalcular';		
	}
	Element.addClassName(imgRecalculo,"imagenCentrada");
	recalculo.appendChild(imgRecalculo);
	return recalculo;
}

function crearDiv(){
	var elemDiv = document.createElement("span");
	elemDiv.id="divActCostes";
	elemDiv.name="divActCostes";	
	Element.addClassName(elemDiv,"capaActCostes");
	var span0 = document.createElement("span");
	Element.addClassName(span0,"spanDoble");
	span0.id="tituloActCostes";	
	var inputActCostes = document.createElement("input");
	inputActCostes.id="inputActCostes";
	inputActCostes.name="inputActCostes";
	Element.addClassName(inputActCostes,"cajaFecha");
	var aFecha1 = document.createElement("a");
	var span3 = document.createElement("span");
	Element.addClassName(span3,"spanDoble");
	span3.id="confirmActCostes";	
	var aAceptar = document.createElement("a");
	asignarFuncion(aAceptar,"funcAceptar()");
	var imgAceptar = document.createElement("img");
	imgAceptar.src = 'img/aceptar.gif';	
	var aCancelar = document.createElement("a");
	asignarFuncion(aCancelar,"funcCancelar()");
	var imgCancelar = document.createElement("img");
	imgCancelar.src = 'img/cancelar.gif';	
	
	span0.appendChild(document.createTextNode("�desea incrementar todos los costes del listado un    "));
	span0.appendChild(inputActCostes);
	span0.appendChild(document.createTextNode("    % ?"));	
	elemDiv.appendChild(span0);	
	
	aAceptar.appendChild(imgAceptar);
	aAceptar.appendChild(document.createTextNode(" Aceptar "));
	span3.appendChild(aAceptar);
	aCancelar.appendChild(document.createTextNode(" Cancelar "));
	aCancelar.appendChild(imgCancelar);
	span3.appendChild(aCancelar);
	elemDiv.appendChild(span3);	
	return elemDiv;
}

function crearNota(){
	var aNota = document.createElement("a");
	aNota.id="aNota";
	aNota.name="aNota";	
	aNota.href='#';
	aNota.appendChild(document.createTextNode(" (*) "));
	asignarFuncion(aNota,"funcNota()");
	var elemDiv = document.createElement("span");
	elemDiv.id="divNota";
	elemDiv.name="divNota";
	elemDiv.appendChild(document.createTextNode("Ser�n 0 todos los datos calculados, siempre que la fecha de entrada o el horametro de entrada est�n vac�os o sean nulos. S�lo cuando se rellenen ambos, podremos hacer el c�lculo de la duraci�n, importes, etc. "));
	aNota.appendChild(elemDiv);
	return aNota;
}

function asignarFuncion(elem,func){
	if (!elem.setAttribute('onClick',func))
		elem['onclick']=new Function(func);	
}

function asignarChange(elem,func){
	if (!elem.setAttribute('onChange',func))
		elem['onchange']=new Function(func);	
}


/////
function funcGenerarLineas(){
	var sel = document.getElementById("albaranes.IDOBRA").selectedIndex;
	var idObra = document.getElementById("albaranes.IDOBRA").options[sel].value;
	var param = "&obras.IDOBRA=" + idObra + "&fecha1=" + document.getElementById("albaranes.FECHACOMIENZO").value + "&fecha2="  + document.getElementById("albaranes.FECHAFIN").value + "&albaran=" + document.getElementById("albaranes.IDALBARAN").value;
	//alert(param);
	var myAjax = new Ajax.Request('/avebie/Albaranes/GenerarLineasAlbaranServlet',{method: 'get', parameters:param, onComplete:avisoFinal});	
}

function avisoFinal(){
	alert("lineas a�adidas");
}

////

function recalcularImporteParteso(){
	var valor = parseFloat(document.getElementById('parteso.IMPORTECONDTO_label').innerHTML);
	document.getElementById('parteso.IMPORTE').value = valor.toFixed(2);
}

function recalcularImportePartesm(){
	var valor = parseFloat(document.getElementById('partesm.IMPORTECONDTO_label').innerHTML);
	document.getElementById('partesm.IMPORTE').value = valor.toFixed(2);
}

function recalcularImporteIncidenciaso(){
	var valor = parseFloat(document.getElementById('incidenciaso.IMPORTECONDTO_label').innerHTML);
	document.getElementById('incidenciaso.IMPORTE').value = valor.toFixed(2);
}

function recalcularImporteIncidenciasm(){
	var valor = parseFloat(document.getElementById('incidenciasm.IMPORTECONDTO_label').innerHTML);
	document.getElementById('incidenciasm.IMPORTE').value = valor.toFixed(2);
}

function recalcularImporteAlquileres(){
	var valorIcdto = parseFloat(document.getElementById('alquileres.IMPORTECONDTO_label').innerHTML);
	var valorIcomb = parseFloat(document.getElementById('alquileres.IMPORTECOMBUSTIBLE_label').innerHTML);
	var valorIport = parseFloat(document.getElementById('alquileres.IMPORTEPORTE_label').innerHTML);
	var valor = valorIcdto + valorIcomb + valorIport;
	document.getElementById('alquileres.IMPORTE').value = valor.toFixed(2);
}

function actualizarCostes(){
	document.getElementById("divActCostes").style.display = "block";
}

function funcAceptar(){
	var valorCoste = document.getElementById("inputActCostes").value;
	if (es_numero(valorCoste)){
		var iVC = parseInt(valorCoste);
		if ((iVC <= 100) && (iVC >= -100)){
			var param = "&iPorcentaje=" + parseInt(valorCoste);
			var myAjax = new Ajax.Request('/avebie/Tipoportes/ActualizaCosteTipoportesServlet',{method: 'get', parameters:param, onComplete:avisoActCostes});	
		}else{
			alert("no es un n� v�lido");
		}
	}
	else
		alert("no es un n�");
	document.getElementById("divActCostes").style.display = "none";
}

function funcCancelar(){
	document.getElementById("divActCostes").style.display = "none";
}

function avisoActCostes(){
	alert("costes actualizados");
	verTipoportes();
}

function funcNota(){
	var el = document.getElementById("divNota");
	if (el.style.display == "none")
		el.style.display = "block";
	else
		el.style.display = "none";
}

//////

function cambioMaqImp(){
	if (document.getElementById("maquinarias.IDTIPOMAQUINARIA").selectedIndex == 1){
		document.getElementById("maquinarias.MATRICULA").parentNode.style.display = "none";
		document.getElementById("maquinarias.MARCA").parentNode.style.width = "750px";
		document.getElementById("maquinarias.BASTIDOR").parentNode.firstChild.nodeValue = "n� serie ";
	}
	else{
		document.getElementById("maquinarias.MATRICULA").parentNode.style.display = "block";
		document.getElementById("maquinarias.MARCA").parentNode.style.width = "350px";
		document.getElementById("maquinarias.BASTIDOR").parentNode.firstChild.nodeValue = "bastidor ";	
	}
}

/////